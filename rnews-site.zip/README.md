# RNews: situs berita pasar otomatis (gratis)

Alur: GitHub Actions (tiap jam) -> ambil RSS -> Claude menulis ulang ringkasan + kategori + label sentimen -> situs statis di folder `public/` -> Cloudflare Pages menayangkan otomatis.

## Langkah pasang (sekitar 30 menit)

1. **Buat repo GitHub**
   - Daftar di github.com, klik New repository, nama `rnews`, pilih Public (Actions gratis tanpa batas).
   - Upload SEMUA isi folder ini, termasuk folder tersembunyi `.github`. Lewat HP paling mudah: unggah ZIP ke komputer atau pakai github.dev / aplikasi Working Copy.

2. **Buat API key Claude**
   - Buka console.anthropic.com, buat API key, lalu isi saldo kecil dan pasang batas pengeluaran bulanan.

3. **Isi rahasia di GitHub**
   - Repo > Settings > Secrets and variables > Actions.
   - Tab Secrets: New secret, nama `ANTHROPIC_API_KEY`, isi key tadi.
   - Tab Variables: New variable, nama `SITE_URL`, isi `https://rnews.pages.dev` dulu (ganti dengan domainmu nanti).

4. **Jalankan pertama kali**
   - Repo > tab Actions > Update RNews > Run workflow.
   - Setelah hijau, folder `public/` dan `data/news.json` muncul di repo.

5. **Tayangkan lewat Cloudflare Pages**
   - dash.cloudflare.com > Workers & Pages > Create > Pages > Connect to Git > pilih repo `rnews`.
   - Framework preset: None. Build command: kosongkan. Build output directory: `public`.
   - Deploy. Situs hidup di alamat `*.pages.dev`. Setiap jam, saat ada berita baru, Cloudflare otomatis memperbarui situs.

6. **Pasang domain**
   - Beli domain (Cloudflare Registrar, Niagahoster, Rumahweb, dll). `.my.id` paling murah; `.id` butuh KTP.
   - Di Cloudflare Pages > projectmu > Custom domains > tambahkan domain, ikuti petunjuk DNS.
   - Ubah variabel `SITE_URL` di GitHub ke domainmu (contoh `https://rnews.my.id`), lalu Run workflow lagi supaya sitemap dan canonical benar.

7. **Daftarkan ke Google**
   - search.google.com/search-console > tambahkan domain > kirim `https://domainmu/sitemap.xml`.

## Sesuaikan

- Sumber berita: edit `scripts/feeds.json`. URL RSS bisa berubah, jadi cek log Actions; feed yang gagal otomatis dilewati. Tambah sumber lain sesuai kebutuhan.
- Biaya: batasi dengan variabel `MAX_NEW` (default 20 berita baru per jam) dan model lewat `CLAUDE_MODEL` (default `claude-haiku-5-5`, model kecil dan murah).
- Uji lokal: `ANTHROPIC_API_KEY=xxx node scripts/build.mjs` (butuh Node 20+).

## Catatan penting

- Situs hanya menampilkan judul tulis ulang + ringkasan orisinal + link ke sumber. Jangan ubah jadi menyalin isi artikel.
- Cek syarat penggunaan RSS tiap sumber, terutama bila nanti memasang iklan.
- Harga BTC, ETH, SOL di bagian atas diambil langsung dari CoinGecko di browser pengunjung. Harga IHSG, emas, dan minyak belum ada karena butuh API data pasar berbayar atau terbatas; bisa ditambah nanti.
- GitHub bisa menghentikan jadwal otomatis jika repo tidak ada aktivitas lama. Kalau berita berhenti, buka tab Actions dan aktifkan lagi.
- Ringkasan oleh AI bisa keliru. Label sentimen hanyalah penilaian kasar, bukan saran investasi.
