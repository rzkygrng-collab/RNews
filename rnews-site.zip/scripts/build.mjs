// RNews: ambil RSS -> tulis ulang dengan Claude -> hasilkan situs statis di /public
import fs from "node:fs";
import crypto from "node:crypto";

const KEY = process.env.ANTHROPIC_API_KEY;
const MODEL = process.env.CLAUDE_MODEL || "claude-haiku-5-5";
const SITE = (process.env.SITE_URL || "https://rnews.pages.dev").replace(/\/$/, "");
const MAX_NEW = +(process.env.MAX_NEW || 20);   // batas berita baru per run (kontrol biaya)
const KEEP = 300, MAX_AGE_H = 48, BATCH = 8;
const CATS = ["Crypto", "Saham", "Ekonomi", "Komoditas", "Forex", "Global"];
const LABELS = ["Bullish", "Netral", "Bearish"];

const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const strip = s => s.replace(/<!\[CDATA\[|\]\]>/g, "").replace(/<[^>]+>/g, " ").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&#8217;/g, "’").replace(/\s+/g, " ").trim();
const tag = (x, t) => { const m = x.match(new RegExp("<" + t + "[^>]*>([\\s\\S]*?)</" + t + ">", "i")); return m ? m[1] : ""; };
const fmt = d => new Date(d).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" });
const slugify = (t, link) => t.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 60) + "-" + crypto.createHash("md5").update(link).digest("hex").slice(0, 6);

async function fetchFeed(f) {
  try {
    const r = await fetch(f.url, { headers: { "user-agent": "RNewsBot/1.0 (+" + SITE + ")" }, signal: AbortSignal.timeout(15000) });
    if (!r.ok) throw new Error("HTTP " + r.status);
    const xml = await r.text();
    return (xml.match(/<item[\s\S]*?<\/item>/gi) || []).map(it => ({
      title: strip(tag(it, "title")), link: strip(tag(it, "link")),
      date: new Date(strip(tag(it, "pubDate")) || Date.now()).toISOString(),
      snippet: strip(tag(it, "description")).slice(0, 400), source: f.name, hint: f.hint
    })).filter(x => x.title && x.link);
  } catch (e) { console.warn("Feed gagal:", f.name, e.message); return []; }
}

async function rewrite(items) {
  const list = items.map((x, i) => ({ id: i, judul: x.title, cuplikan: x.snippet, sumber: x.source }));
  const prompt = `Kamu editor pasar keuangan Indonesia. Untuk setiap berita di bawah, tulis ulang SEPENUHNYA dengan kata-katamu sendiri dalam bahasa Indonesia (jangan menyalin kalimat asli, jangan menambah fakta yang tidak ada di cuplikan).
Balas HANYA JSON array tanpa teks lain. Tiap elemen: {"id":number,"judul":"judul baru maks 100 karakter","ringkasan":"2-3 kalimat","kategori":"salah satu dari ${CATS.join("|")}","tag":["maks 4 simbol/nama, mis. BTC, IHSG, Emas"],"sentimen":"Bullish|Netral|Bearish"}.
Sentimen = dampak berita pada pasar terkait (Bullish naik, Bearish turun, Netral campuran/tidak jelas).
Berita: ${JSON.stringify(list)}`;
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "content-type": "application/json", "x-api-key": KEY, "anthropic-version": "2023-06-01" },
    body: JSON.stringify({ model: MODEL, max_tokens: 4000, messages: [{ role: "user", content: prompt }] })
  });
  const j = await r.json();
  if (!j.content) throw new Error("API error: " + JSON.stringify(j).slice(0, 300));
  const txt = j.content.map(c => c.text || "").join("");
  return JSON.parse(txt.slice(txt.indexOf("["), txt.lastIndexOf("]") + 1));
}

// ---------- tampilan ----------
const CSS = `:root{--bg:#f5f7fb;--card:#fff;--tx:#0f172a;--mu:#64748b;--bd:#e2e8f0;--ac:#2563eb;--up:#059669;--dn:#dc2626;--nt:#d97706;--upb:#d1fae5;--dnb:#fee2e2;--ntb:#fef3c7;color-scheme:light}
@media(prefers-color-scheme:dark){:root:not([data-theme=light]){--bg:#0b1120;--card:#131c31;--tx:#e8edf7;--mu:#94a3b8;--bd:#24304a;--ac:#60a5fa;--up:#34d399;--dn:#f87171;--nt:#fbbf24;--upb:#064e3b;--dnb:#7f1d1d;--ntb:#78350f;color-scheme:dark}}
:root[data-theme=dark]{--bg:#0b1120;--card:#131c31;--tx:#e8edf7;--mu:#94a3b8;--bd:#24304a;--ac:#60a5fa;--up:#34d399;--dn:#f87171;--nt:#fbbf24;--upb:#064e3b;--dnb:#7f1d1d;--ntb:#78350f;color-scheme:dark}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--tx);font:16px/1.6 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;padding-top:env(safe-area-inset-top,0)}
a{color:inherit;text-decoration:none}.w{max-width:1100px;margin:0 auto;padding:0 16px}
header{position:sticky;top:0;z-index:5;background:var(--card);border-bottom:1px solid var(--bd)}
.bar{display:flex;align-items:center;gap:12px;padding:12px 0;flex-wrap:wrap}.logo{font-weight:800;font-size:1.6rem;margin:0}.logo span{color:var(--ac)}.tag1{color:var(--mu);font-size:.8rem;flex:1;min-width:140px}
input,button{font:inherit;color:var(--tx)}.s{flex:1;min-width:150px;max-width:280px;padding:8px 12px;border:1px solid var(--bd);border-radius:10px;background:var(--bg)}
.b{padding:8px 14px;border:1px solid var(--bd);border-radius:10px;background:var(--bg);cursor:pointer}
nav{display:flex;gap:8px;overflow-x:auto;padding:0 0 12px;scrollbar-width:none}nav button{white-space:nowrap;padding:6px 14px;border:1px solid var(--bd);border-radius:99px;background:var(--bg);cursor:pointer}nav button.on{background:var(--ac);color:#fff;border-color:var(--ac)}
.tk{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;margin:18px 0}.ti{background:var(--card);border:1px solid var(--bd);border-radius:12px;padding:10px 12px}.ti small{display:block;color:var(--mu);font-size:.72rem}.ti b{font-size:1rem}
.hero{background:var(--card);border:1px solid var(--bd);border-radius:16px;padding:18px;margin-bottom:20px}.hero h2{margin:0 0 4px;font-size:1.05rem}.big{font-size:1.7rem;font-weight:800;margin:4px 0}
.gauge{display:flex;height:12px;border-radius:99px;overflow:hidden;background:var(--bd);margin:10px 0 6px}.gauge i{display:block}.leg{display:flex;justify-content:space-between;font-size:.85rem;font-weight:600}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(290px,1fr));gap:16px;margin-bottom:28px}
.c{background:var(--card);border:1px solid var(--bd);border-radius:16px;padding:16px;display:flex;flex-direction:column;gap:8px;transition:transform .15s}.c:hover{transform:translateY(-2px)}
.c h3{margin:0;font-size:1.05rem;line-height:1.35}.c p{margin:0;color:var(--mu);font-size:.92rem}
.meta{display:flex;gap:8px;align-items:center;flex-wrap:wrap;font-size:.78rem;color:var(--mu)}.chip{padding:2px 9px;border-radius:99px;font-weight:700;font-size:.75rem}
.Bullish{background:var(--upb);color:var(--up)}.Bearish{background:var(--dnb);color:var(--dn)}.Netral{background:var(--ntb);color:var(--nt)}
.cat{background:var(--bg);border:1px solid var(--bd);color:var(--ac)}.tg{padding:1px 8px;border-radius:6px;background:var(--bg);border:1px solid var(--bd);font-size:.72rem}
article.p{max-width:720px;margin:24px auto;background:var(--card);border:1px solid var(--bd);border-radius:16px;padding:22px}article.p h1{font-size:1.5rem;line-height:1.3}.lk{color:var(--ac);font-weight:600}
footer{border-top:1px solid var(--bd);padding:20px 0 28px;color:var(--mu);font-size:.8rem;text-align:center}`;

const head = (title, desc, url, extra = "") => `<!DOCTYPE html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>${esc(title)}</title><meta name="description" content="${esc(desc)}"><link rel="canonical" href="${esc(url)}">
<meta property="og:title" content="${esc(title)}"><meta property="og:description" content="${esc(desc)}"><meta property="og:url" content="${esc(url)}"><meta property="og:type" content="website">
<style>${CSS}</style>${extra}</head><body>`;
const foot = `<footer><div class="w">© ${new Date().getFullYear()} RNews. Ringkasan ditulis ulang otomatis dan bukan saran investasi. Hak cipta berita ada pada sumber aslinya.</div></footer></body></html>`;
const bar = `<header><div class="w"><div class="bar"><a href="/"><h1 class="logo">R<span>News</span></h1></a><div class="tag1">Analisa berita &amp; sentimen pasar</div>`;

const card = n => `<a class="c" href="/berita/${n.slug}.html" data-c="${esc(n.kategori)}"><div class="meta"><span class="chip cat">${esc(n.kategori)}</span><span class="chip ${n.sentimen}">${n.sentimen}</span><span>${fmt(n.date)}</span></div><h3>${esc(n.judul)}</h3><p>${esc(n.ringkasan.slice(0, 170))}${n.ringkasan.length > 170 ? "…" : ""}</p><div class="meta">${(n.tag || []).map(t => `<span class="tg">${esc(t)}</span>`).join("")}</div><div class="meta">Sumber: ${esc(n.source)}</div></a>`;

function renderIndex(news) {
  const u = news.filter(n => n.sentimen === "Bullish").length, d = news.filter(n => n.sentimen === "Bearish").length, n0 = news.length - u - d, t = news.length || 1;
  const L = (u - d) / t >= .25 ? "Bullish" : (u - d) / t <= -.25 ? "Bearish" : "Netral";
  const col = L === "Bullish" ? "var(--up)" : L === "Bearish" ? "var(--dn)" : "var(--nt)";
  const script = `var cur="Semua",q="";function ap(){document.querySelectorAll(".c").forEach(function(a){var ok=(cur==="Semua"||a.dataset.c===cur)&&(!q||a.textContent.toLowerCase().indexOf(q)>-1);a.style.display=ok?"":"none"})}
document.querySelectorAll("nav button").forEach(function(b){b.onclick=function(){cur=b.dataset.c;document.querySelectorAll("nav button").forEach(function(x){x.classList.toggle("on",x===b)});ap()}});
document.getElementById("q").oninput=function(e){q=e.target.value.toLowerCase();ap()};
document.getElementById("th").onclick=function(){var r=document.documentElement;r.setAttribute("data-theme",r.getAttribute("data-theme")==="dark"?"light":"dark")};
fetch("https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,solana&vs_currencies=usd&include_24hr_change=true").then(function(r){return r.json()}).then(function(d){
[["bitcoin","Bitcoin"],["ethereum","Ethereum"],["solana","Solana"]].forEach(function(p){var o=d[p[0]];if(!o)return;var e=document.createElement("div");e.className="ti";var ch=o.usd_24h_change||0;e.innerHTML="<small>"+p[1]+" (live)</small><b>$"+Math.round(o.usd).toLocaleString("en-US")+"</b><small style=\\"color:var("+(ch>=0?"--up":"--dn")+")\\">"+(ch>=0?"+":"")+ch.toFixed(2)+"% 24j</small>";document.getElementById("tk").appendChild(e)})}).catch(function(){});`;
  return head("RNews – Berita & Sentimen Pasar Crypto, Saham, Ekonomi Hari Ini", "Berita pasar terkini dengan ringkasan orisinal dan label sentimen Bullish/Netral/Bearish untuk crypto, saham, ekonomi, komoditas, dan forex.", SITE + "/",
    `<script type="application/ld+json">${JSON.stringify({ "@context": "https://schema.org", "@type": "NewsMediaOrganization", name: "RNews", url: SITE, inLanguage: "id" })}</script>`) +
    bar + `<input class="s" id="q" type="search" placeholder="Cari berita…" aria-label="Cari"><button class="b" id="th" aria-label="Tema">◐</button></div><nav>${["Semua", ...CATS].map((c, i) => `<button data-c="${c}" class="${i ? "" : "on"}">${c}</button>`).join("")}</nav></div></header>
<main class="w"><section class="tk" id="tk"></section>
<section class="hero"><h2>Sentimen Pasar Keseluruhan</h2><div style="color:var(--mu);font-size:.85rem">Dari ${news.length} berita terbaru</div><div class="big" style="color:${col}">Cenderung ${L}</div>
<div class="gauge"><i style="width:${u / t * 100}%;background:var(--up)"></i><i style="width:${n0 / t * 100}%;background:var(--nt)"></i><i style="width:${d / t * 100}%;background:var(--dn)"></i></div>
<div class="leg"><span style="color:var(--up)">Bullish ${u}</span><span style="color:var(--nt)">Netral ${n0}</span><span style="color:var(--dn)">Bearish ${d}</span></div></section>
<h2 style="font-size:1.2rem">Berita Terkini</h2><section class="grid">${news.slice(0, 120).map(card).join("")}</section></main>${foot.replace("</body>", `<script>${script}</script></body>`)}`;
}

function renderArticle(n) {
  const url = SITE + "/berita/" + n.slug + ".html";
  const ld = { "@context": "https://schema.org", "@type": "NewsArticle", headline: n.judul, datePublished: n.date, inLanguage: "id", description: n.ringkasan, publisher: { "@type": "Organization", name: "RNews" }, mainEntityOfPage: url };
  return head(n.judul + " | RNews", n.ringkasan.slice(0, 155), url, `<script type="application/ld+json">${JSON.stringify(ld)}</script>`) +
    bar + `</div></div></header><article class="p"><div class="meta"><span class="chip cat">${esc(n.kategori)}</span><span class="chip ${n.sentimen}">${n.sentimen}</span><span>${fmt(n.date)}</span></div>
<h1>${esc(n.judul)}</h1><p>${esc(n.ringkasan)}</p><div class="meta">${(n.tag || []).map(t => `<span class="tg">${esc(t)}</span>`).join("")}</div>
<p style="color:var(--mu);font-size:.9rem">Sumber: ${esc(n.source)}. Ringkasan ini ditulis ulang otomatis dan bukan saran investasi.</p>
<p><a class="lk" href="${esc(n.link)}" target="_blank" rel="nofollow noopener noreferrer">Baca berita lengkap di sumber ↗</a></p><p><a class="lk" href="/">← Kembali ke RNews</a></p></article>` + foot;
}

// ---------- alur utama ----------
fs.mkdirSync("data", { recursive: true });
let db = fs.existsSync("data/news.json") ? JSON.parse(fs.readFileSync("data/news.json", "utf8")) : [];
const known = new Set(db.map(x => x.link));

if (!KEY) { console.warn("ANTHROPIC_API_KEY kosong: lewati pengambilan berita baru, hanya render ulang situs."); }
else {
  const feeds = JSON.parse(fs.readFileSync("scripts/feeds.json", "utf8"));
  const all = (await Promise.all(feeds.map(fetchFeed))).flat();
  const cutoff = Date.now() - MAX_AGE_H * 3600e3;
  const seen = new Set();
  const fresh = all.filter(x => !known.has(x.link) && !seen.has(x.link) && seen.add(x.link) && new Date(x.date) > cutoff)
    .sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, MAX_NEW);
  console.log("Berita baru:", fresh.length);
  for (let i = 0; i < fresh.length; i += BATCH) {
    const part = fresh.slice(i, i + BATCH);
    try {
      const out = await rewrite(part);
      for (const o of out) {
        const src = part[o.id]; if (!src || !o.judul || !o.ringkasan) continue;
        db.push({ link: src.link, source: src.source, date: src.date, slug: slugify(o.judul, src.link), judul: o.judul, ringkasan: o.ringkasan,
          kategori: CATS.includes(o.kategori) ? o.kategori : (src.hint || "Global"), tag: (o.tag || []).slice(0, 4), sentimen: LABELS.includes(o.sentimen) ? o.sentimen : "Netral" });
      }
    } catch (e) { console.warn("Batch gagal:", e.message); }
  }
}
db = db.sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, KEEP);
fs.writeFileSync("data/news.json", JSON.stringify(db, null, 1));

fs.rmSync("public", { recursive: true, force: true });
fs.mkdirSync("public/berita", { recursive: true });
fs.writeFileSync("public/index.html", renderIndex(db));
db.forEach(n => fs.writeFileSync(`public/berita/${n.slug}.html`, renderArticle(n)));
fs.writeFileSync("public/sitemap.xml", `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>${SITE}/</loc></url>${db.map(n => `<url><loc>${SITE}/berita/${n.slug}.html</loc><lastmod>${n.date.slice(0, 10)}</lastmod></url>`).join("")}</urlset>`);
fs.writeFileSync("public/robots.txt", `User-agent: *\nAllow: /\nSitemap: ${SITE}/sitemap.xml\n`);
console.log("Selesai. Total berita:", db.length);
